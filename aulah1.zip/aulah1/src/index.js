//importando pacote express
const { response } = require("express");
const express = require("express");
const { get, request } = require("http");
const { uuid } = require('uuidv4');

//preparar para usar express
const app = express();
app.use(express.json());

const repositories = [];

// 1 parametro o nome da rota
// 2 parametro ação qeu vou fazer função  
// java script arrow function
// (parametros) => {codigos programa fazer}

app.get('/', (request,response)=>{
//codigo funcao

return response.send(repositories);

});

app.post('/', (request, response) => {

const { name , email, cpf, idade, altura, peso }  = request.body;
const newPaciente = { id : uuid() , name , email, cpf, idade, altura,peso};
repositories.push({newPaciente});

return response.json ({newPaciente});



}); 


app.put ('/:id', (request,response) => {
//route params guid

const {id} = request.params;
const { name , email, cpf, idade, altura, peso }  = request.body;
const PacienteProcurado = repositories.findIndex(pacienteIndex => pacienteIndex.id == id);


console.log(id);
console.log(request.body);
console.log(PacienteProcurado);
console.log(repositories);

if (PacienteProcurado < 0){

    return response.status(404).json({"ERROR":"Paciente não encontrado"});

          }

    const newPaciente =  {id , name , email , cpf, idade, altura, peso};
    repositories[PacienteProcurado] = newPaciente;
    return response.json(newPaciente);

});

app.delete('/:id', (request,response) =>{

const {id} = request.params;

const PacienteProcurado = repositories.findIndex(pacienteIndex => pacienteIndex.id == id);
if (PacienteProcurado < 0){

    return response.status(404).json({"ERROR" : `Paciente ${id} não encontrado`});

     }

    repositories.splice(PacienteProcurado,1);
    return response.json({"Mensagem" : `Paciente ${id} removido`});

    
    });





app.listen(3333, ()=>{

console.log("Server running");


})

